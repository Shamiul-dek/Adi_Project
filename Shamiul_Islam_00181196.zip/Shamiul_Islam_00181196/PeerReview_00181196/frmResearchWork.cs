﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmResearchWork : Form
    {
        string sourcefile;
        Database1Entities db = new Database1Entities();
        string authorId = "";
        public frmResearchWork()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Title = "Select file to be upload.";
            openFileDialog1.Filter = "Document(*.pdf; *.doc)|*.pdf; *.docx";
            openFileDialog1.FilterIndex = 1;
            try
            {
                if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
                {
                                 

                        if (openFileDialog1.CheckFileExists)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                            sourcefile = path;
                            string filename = System.IO.Path.GetFileName(openFileDialog1.FileName);
                            txtDocName.Text = filename;

                            string ext = System.IO.Path.GetExtension(openFileDialog1.FileName);
                            txtDocType.Text = ext.Substring(1);

                            btnSubmit.Enabled = txtDocName.Text != "";
                        }//End of inner if
                    }//end of outer if

                }//end od try
            
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }//End of Catch
            
           
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //try
            //{
                if (txtDocName.Text == null)
                {
                    MessageBox.Show("please select a valid document");
                }
                else
                {
                    //..............db.............
                    ResearchWork w = new ResearchWork();
                    w.Doc = txtDocName.Text;
                    w.uDate = dateTimePicker1.Value;
                    w.dType = txtDocType.Text;
                    w.aId = Int32.Parse(authorId);
                    w.skillId = Int32.Parse(comboBox1.SelectedValue.ToString());
                    w.isReviewer = false;

                    db.ResearchWorks.Add(w);
                    db.SaveChanges();

                    txtId.Text = w.Id.ToString();

                    //File upload
                    string path = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
                    System.IO.File.Copy(sourcefile, path + "\\Upload\\" + txtDocName.Text, true);

                    //Insert data into document
                    DocumentTag dt = new DocumentTag();
                    dt.docId = w.Id;
                    dt.skillId = (int)w.skillId;
                    db.DocumentTags.Add(dt);
                    db.SaveChanges();

                    MessageBox.Show("Document upload successfully");
               
                }

            //}
            //catch (Exception ex)
            //{

            //    MessageBox.Show(ex.Message);
            //}
        }

        private void frmResearchWork_Load(object sender, EventArgs e)
        {
            var data = db.Authors.Where(d => d.uId == clsUserData.UserId).FirstOrDefault();

            if (data == null)
            {
                MessageBox.Show("No Authors found");
                this.Close();
                return;
            }
            authorId = data.Id.ToString();
            btnSubmit.Enabled = false;

            //Get AuthorID
            var aid = db.Authors.Where(d => d.uId == clsUserData.UserId).FirstOrDefault();
            //GET AUTHOR SKILL INFORMATION
            var sdata = db.AuthorSkills.Select(a => new { a.authorId, a.skillId, SkillName = a.Skill.Name })
                .Where(d => d.authorId == aid.Id).ToList();

            comboBox1.DataSource = sdata;
            comboBox1.DisplayMember = "SkillName";
            comboBox1.ValueMember = "skillId";   
           

        }
    }
}
       
    


           
