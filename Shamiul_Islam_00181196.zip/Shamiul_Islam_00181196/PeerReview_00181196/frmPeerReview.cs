﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmPeerReview : Form
    {
        Database1Entities db = new Database1Entities();
        public frmPeerReview()
        {
            InitializeComponent();
        }

        private void frnPeerReview_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            //--Get skillid Combobox data from Research work 
            var data2 = db.ResearchWorks.Select(d => new { d.Doc, d.Skill.Id }).ToList();

            cboDocId.DataSource = data2;
            cboDocId.DataSource = data2;
            cboDocId.DisplayMember = "Doc";
            cboDocId.ValueMember = "Id";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //-------db----

            PeerReview pr = new PeerReview();

            pr.DOR = dateTimePicker1.Value;
            pr.reviewerId = Int32.Parse(cboRevId.SelectedValue.ToString());
            pr.docId = Int32.Parse(cboDocId.SelectedValue.ToString());
            pr.isComments = false;

            db.PeerReviews.Add(pr);
            db.SaveChanges();

            txtId.Text = pr.Id.ToString();

            //Modify Research Work
            var rw = db.ResearchWorks.Where(d => d.Doc == cboDocId.Text).FirstOrDefault();
            rw.isReviewer = true;
            db.SaveChanges();

            RefreshData();   
                   
        }

        private void cboDocId_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //---get combobox data from reviewer
            int rSkillId = Int32.Parse(cboDocId.SelectedValue.ToString());

            var rdata = db.ReviewerSkills.Select(a => new { a.reviewerId, a.skillId, ReviewerName = a.Reviewer.Name })
                .Where(d => d.reviewerId == rSkillId).ToList();

            cboRevId.DataSource = rdata;
            cboRevId.DisplayMember = "ReviewerName";
            cboRevId.ValueMember = "reviewerid"; 
        }
    }
}
