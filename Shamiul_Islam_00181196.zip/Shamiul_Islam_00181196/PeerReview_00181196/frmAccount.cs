﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmAccount : Form
    {
        Database1Entities db = new Database1Entities();
        public frmAccount()
        {
            InitializeComponent();
        }

        private void frmAccount_Load(object sender, EventArgs e)
        {
            IEnumerable <UserRole> data;
            if (clsUserData.RoleName == "Admin")
            {
                data = db.UserRoles.ToList();
            }
            else
            {
                data = db.UserRoles.Where(d => d.Name != "Admin").ToList();
            }

            CboUType.DataSource = data;
            CboUType.DisplayMember = "Name";
            CboUType.ValueMember = "Id";         

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                UserInfo u = new UserInfo();

                u.Name = txtName.Text;
                u.Email = txtEmail.Text;
                u.Pass = txtPassword.Text;
                u.rId = Int32.Parse(CboUType.SelectedValue.ToString());

                db.UserInfoes.Add(u);
                db.SaveChanges();
                txtId.Text = u.Id.ToString();

                MessageBox.Show("Data inserted successfully..!", "Insert", MessageBoxButtons.OK,
                                     MessageBoxIcon.Information); 

            }
            catch (Exception)
            {

                MessageBox.Show("Data Already Exist..!", "Insert", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
            }
        }
    }
}
