﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmAuthor : Form
    {
        Database1Entities db = new Database1Entities();
        public frmAuthor()
        {
            InitializeComponent();
        }

        private void frmAuthor_Load(object sender, EventArgs e)
        {
            var data1 = db.Skills.Select(d => new { d.Id, d.Name }).ToList();

            listBox1.DataSource = data1;
            listBox1.DisplayMember = "Name";
            listBox1.ValueMember = "Id";
            listBox1.SelectionMode = SelectionMode.MultiSimple;

            if (data1.Count == 0)
            {
                MessageBox.Show("No Skills Found..!!");
                btnSubmit.Enabled = false;
            }
            else
            {
                btnSubmit.Enabled = true;
            }

            txtName.Text = clsUserData.UserName;
            txtEmail.Text = clsUserData.UserEmail;

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                var ainfo = db.Authors.Where(d => d.Name == txtName.Text).FirstOrDefault();

                if (ainfo == null)
                {
                    Author au = new Author()
                    {
                        Name = txtName.Text,
                        Email = txtEmail.Text,
                        DOB = dateTimePicker1.Value,
                        uId = clsUserData.UserId
                    };

                    db.Authors.Add(au);
                    db.SaveChanges();
                    txtId.Text = au.Id.ToString();

                    foreach (object item in listBox1.SelectedItems)
                    {
                        string idn = item.ToString().Split(',')[0].Substring(6);                        

                        AuthorSkill ask = new AuthorSkill();
                        ask.authorId = ainfo.Id;
                        ask.skillId = Int32.Parse(idn);

                        db.AuthorSkills.Add(ask);
                        db.SaveChanges();                      

                    }

                    MessageBox.Show("author and skill data inserted successflly");
                }



                else
                {
                    txtId.Text = ainfo.Id.ToString();

                    foreach (object item in listBox1.SelectedItems)
                    {
                        string idn = item.ToString().Split(',')[0].Substring(6);
                        int idnum = Int32.Parse(idn);

                        var authSkill = db.AuthorSkills.Where(d => d.authorId == ainfo.Id && d.skillId == idnum).FirstOrDefault();

                        if (authSkill == null)
                        {

                            AuthorSkill ask = new AuthorSkill();
                            ask.authorId = ainfo.Id;
                            ask.skillId = Int32.Parse(idn);

                            db.AuthorSkills.Add(ask);
                            db.SaveChanges();

                            if (ask.Id != 0)
                            {
                                MessageBox.Show("Skill Data Inserted Successfully...!!!"); 
                            }
                        }
                        else
                        {
                            MessageBox.Show("Skill Already Exist");   
                        }//End of inner if
                    }//End of foreach loop
                }//End of outer if
            }

            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }  
        }
    }
}
