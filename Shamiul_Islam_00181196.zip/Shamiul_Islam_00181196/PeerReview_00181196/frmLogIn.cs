﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmLogIn : Form
    {
        Database1Entities db = new Database1Entities();
        public frmLogIn()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAccount frm = new frmAccount();
            frm.ShowDialog();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            var user = db.UserInfoes.Where(d => d.Email.ToLower() == txtEmail.Text.ToLower() &&
                                            d.Pass == txtPass.Text).FirstOrDefault();
            if (user != null)
            {
                clsUserData.UserId = (int)user.Id;
                clsUserData.UserName = user.Name;
                clsUserData.UserEmail = user.Email;
                clsUserData.RoleName = user.UserRole.Name;

                this.Hide();
                frmMain frm = new frmMain();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Not a Valid User");   
            }
              
        }
    }
}
