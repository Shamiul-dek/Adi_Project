﻿namespace PeerReview_00181196
{
    partial class frmConference
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.startdate = new System.Windows.Forms.Label();
            this.pDescroption = new System.Windows.Forms.Label();
            this.cTitle = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lebel1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(46, 340);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 32);
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.txtDescription);
            this.groupBox1.Controls.Add(this.txtTitle);
            this.groupBox1.Controls.Add(this.startdate);
            this.groupBox1.Controls.Add(this.pDescroption);
            this.groupBox1.Controls.Add(this.cTitle);
            this.groupBox1.Controls.Add(this.txtId);
            this.groupBox1.Controls.Add(this.lebel1);
            this.groupBox1.Location = new System.Drawing.Point(23, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 291);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Conference Information";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(156, 249);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(156, 123);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescription.Size = new System.Drawing.Size(200, 120);
            this.txtDescription.TabIndex = 11;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(156, 79);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(200, 22);
            this.txtTitle.TabIndex = 10;
            // 
            // startdate
            // 
            this.startdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.startdate.Location = new System.Drawing.Point(23, 249);
            this.startdate.Name = "startdate";
            this.startdate.Size = new System.Drawing.Size(100, 23);
            this.startdate.TabIndex = 9;
            this.startdate.Text = "start Date";
            this.startdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pDescroption
            // 
            this.pDescroption.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pDescroption.Location = new System.Drawing.Point(23, 122);
            this.pDescroption.Name = "pDescroption";
            this.pDescroption.Size = new System.Drawing.Size(100, 23);
            this.pDescroption.TabIndex = 9;
            this.pDescroption.Text = "Description:";
            this.pDescroption.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cTitle
            // 
            this.cTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cTitle.Location = new System.Drawing.Point(23, 78);
            this.cTitle.Name = "cTitle";
            this.cTitle.Size = new System.Drawing.Size(100, 23);
            this.cTitle.TabIndex = 8;
            this.cTitle.Text = "Title:";
            this.cTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(156, 33);
            this.txtId.Name = "txtId";
            this.txtId.ReadOnly = true;
            this.txtId.Size = new System.Drawing.Size(100, 22);
            this.txtId.TabIndex = 7;
            // 
            // lebel1
            // 
            this.lebel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lebel1.Location = new System.Drawing.Point(23, 32);
            this.lebel1.Name = "lebel1";
            this.lebel1.Size = new System.Drawing.Size(100, 23);
            this.lebel1.TabIndex = 1;
            this.lebel1.Text = "Id:";
            this.lebel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmConference
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 384);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmConference";
            this.Text = "frmConference";
            this.Load += new System.EventHandler(this.frmConference_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label startdate;
        private System.Windows.Forms.Label pDescroption;
        private System.Windows.Forms.Label cTitle;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lebel1;
    }
}