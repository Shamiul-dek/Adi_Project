﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmUserRolelist : Form
    {
        Database1Entities db = new Database1Entities();

        public frmUserRolelist()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
        private void frmUserRolelist_Load(object sender, EventArgs e)
        {
            var data = db.UserRoles.Select(d => new {d.Id, d.Name} ).ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = data;
         
        }

        
    }
}
