﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmComment : Form
    {
        Database1Entities db = new Database1Entities();
        public frmComment()
        {
            InitializeComponent();
        }

        private void frmComment_Load(object sender, EventArgs e)
        {
            ///get reviewer ID
            int uid = clsUserData.UserId;
            var revw = db.Reviewers.Where(d => d.uId == uid).FirstOrDefault();
            int reviewerId = revw.Id;

            //------Get Combobox data from Peerreview=====
            var data1 = db.PeerReviews.Select(d => new { d.Id, Name = d.Reviewer.Name, d.reviewerId, d.ResearchWork.Doc, d.isComments })
                .Where(p => p.reviewerId == reviewerId && p.isComments == false).ToList();

            // var data1 = db.PeerReviews.ToList();

            if (data1.Count == 0)
            {
                MessageBox.Show("No Data to Comments");
                btnSubmit.Enabled = false;
                return;
            }

            cboReview.DataSource = null;
            cboReview.DisplayMember = "Doc";
            cboReview.ValueMember = "Id";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //---db=-------
            Comment cmt = new Comment();

            cmt.peerRevId = Int32.Parse(cboReview.SelectedValue.ToString());
            cmt.Remark = txtRemark.Text;
            cmt.cDate = dateTimePicker1.Value;

            db.Comments.Add(cmt);
            db.SaveChanges();

            txtId.Text = cmt.Id.ToString();

            //update peer data
            var pData = db.PeerReviews.Where(d => d.Id == cmt.peerRevId).FirstOrDefault();
            pData.isComments = true;
            db.SaveChanges();
        }
    }
}
