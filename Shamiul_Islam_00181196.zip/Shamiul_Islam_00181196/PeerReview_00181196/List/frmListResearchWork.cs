﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListResearchWork : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListResearchWork()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmListResearchWork_Load(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new
            {
                d.Id,
                d.Doc,
                d.uDate,
                d.dType,
                AuthorName = d.Author.Name,
                SkillName = d.Skill.Name
            }).ToList();

            dataGridView1.DataSource = data;
            
        }
    }
}
