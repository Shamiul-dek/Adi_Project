﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListAuthor : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListAuthor()
        {
            InitializeComponent();
        }

        private void lblFormload_Click(object sender, EventArgs e)
        {

        }

        private void frmListAuthor_Load(object sender, EventArgs e)
        {
            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                //get author id

                var auth = db.Authors.Where(d => d.uId == clsUserData.UserId).FirstOrDefault();
                if (auth != null)
                {


                    var data = db.AuthorSkills.Select(d => new
                    {
                        d.Author.Id,
                        d.Author.Name,
                        d.Author.Email,
                        dateofbirth = d.Author.DOB,
                        Skill = d.Skill.Name
                    }).Where(d => d.Id == auth.Id).ToList();
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = data;
                }
                else
                {
                    MessageBox.Show("AuthOr Information not found...!!!");
                    this.Close();
                }
            }
            else
            {
                var data = db.AuthorSkills.Select(d => new { d.Author.Id, d.Author.Name, d.Author.Email,
                                                dateofbirth = d.Author.DOB, Skill = d.Skill.Name }).ToList();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = data;
            }
            
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
