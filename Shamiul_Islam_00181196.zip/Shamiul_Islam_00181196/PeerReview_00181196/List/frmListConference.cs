﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListConference : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListConference()
        {
            InitializeComponent();
        }

        private void frmListConference_Load(object sender, EventArgs e)
        {
            var data = db.ProjectConferences.Select(d => new
            {
                d.Id,
                d.cTitle,
                d.pDescription,
                d.StartDate
            }).ToList();

            dataGridView1.DataSource = data;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            var data = db.ProjectConferences.Select(d => new
            {
                d.Id,
                d.cTitle,
                d.pDescription,
                d.StartDate
            }).Where(d => d.StartDate >= DateTime.Now).ToList();

            dataGridView1.DataSource = data;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            var data = db.ProjectConferences.Select(d => new
            {
                d.Id,
                d.cTitle,
                d.pDescription,
                d.StartDate
            }).Where(d => d.StartDate < DateTime.Now).ToList();

            dataGridView1.DataSource = data;
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            var data = db.ProjectConferences.Select(d => new
            {
                d.Id,
                d.cTitle,
                d.pDescription,
                d.StartDate
            }).ToList();

            dataGridView1.DataSource = data;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
