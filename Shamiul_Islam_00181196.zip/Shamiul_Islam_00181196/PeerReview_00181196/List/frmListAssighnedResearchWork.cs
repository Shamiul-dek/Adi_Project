﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListAssighnedResearchWork : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListAssighnedResearchWork()
        {
            InitializeComponent();
        }

        private void frmListAssighnedResearchWork_Load(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new
            {
                d.Id,
                d.Doc,
                d.uDate,
                d.dType,
                AuthorName = d.Author.Name,
                SkillName = d.Skill.Name,
                d.isReviewer
            }).Where(d => d.isReviewer == false).ToList();

            dataGridView1.DataSource = data;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        } 

        private void button2_Click(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new
            {
                d.Id,
                d.Doc,
                d.uDate,
                d.dType,
                AuthorName = d.Author.Name,
                SkillName = d.Skill.Name,
                d.isReviewer
            }).Where(d => d.isReviewer == true).ToList();

            dataGridView1.DataSource = data;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var data = db.ResearchWorks.Select(d => new
            {
                d.Id,
                d.Doc,
                d.uDate,
                d.dType,
                AuthorName = d.Author.Name,
                SkillName = d.Skill.Name,
                d.isReviewer
            }).Where(d => d.isReviewer == false).ToList();

            dataGridView1.DataSource = data;
        }
    }
}
