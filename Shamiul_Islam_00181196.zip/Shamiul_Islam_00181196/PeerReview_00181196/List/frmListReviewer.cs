﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListReviewer : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListReviewer()
        {
            InitializeComponent();
        }

        private void frmListReviewer_Load(object sender, EventArgs e)
        {
            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                //get reviewer id


                var rev = db.Reviewers.Where(d => d.uId == clsUserData.UserId).FirstOrDefault();
                if (rev != null)
                {


                    var data = db.ReviewerSkills.Select(d => new
                    {
                        d.Reviewer.Id,
                        d.Reviewer.Name,
                        d.Reviewer.Email,
                        DateOfBirth = d.Reviewer.DOB,
                        Skill = d.Skill.Name
                    }).Where(d => d.Id == rev.Id).ToList();


                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = data;
                }

                else
                {
                    MessageBox.Show("Reviewer Information not found...!!!");
                    this.Close();
                }
            }
            else
            {
                var data = db.ReviewerSkills.Select(d => new {
                    d.Reviewer.Id,
                    d.Reviewer.Name,
                    d.Reviewer.Email,
                    DateOfBirth = d.Reviewer.DOB,
                    Skill = d.Skill.Name
                }).ToList();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = data;
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
