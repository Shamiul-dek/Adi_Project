﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196.List
{
    public partial class frmListUserInfo : Form
    {
        Database1Entities db = new Database1Entities();
        public frmListUserInfo()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmListUserInfo_Load(object sender, EventArgs e)
        {
            if (clsUserData.RoleName.ToLower() != "AAdmin".ToLower())
            {
                var data = db.UserInfoes.Select(d => new
                {
                    d.Id,
                    d.Name,
                    d.Email,
                    Password = "****", //d.pass
                    UserType = d.UserRole.Name
                }).ToList();

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = data;
            }  

            else{
                    var data = db.UserInfoes.Select(d => new
                    {
                        d.Id,
                        d.Email,
                        password = d.Pass,
                        UserType = d.UserRole.Name
                    }).ToList();

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = data;

                }
            }
        }
    }

        

            

            
           
            
        
    

