﻿namespace PeerReview_00181196
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.appToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regularUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.authorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.documentUploadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.peerReviewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ratingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.documentDownloadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userRoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.listToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allRoleInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skillInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skillInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.researchWorkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ratingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userRoleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewerResearchWorkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appToolStripMenuItem,
            this.fileToolStripMenuItem,
            this.listToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(543, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // appToolStripMenuItem
            // 
            this.appToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.appToolStripMenuItem.Name = "appToolStripMenuItem";
            this.appToolStripMenuItem.Size = new System.Drawing.Size(49, 24);
            this.appToolStripMenuItem.Text = "&App";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.logOutToolStripMenuItem.Text = "Log out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regularUserToolStripMenuItem,
            this.skillToolStripMenuItem,
            this.authorToolStripMenuItem1,
            this.conferenceToolStripMenuItem1,
            this.documentUploadToolStripMenuItem,
            this.reviewerToolStripMenuItem1,
            this.peerReviewerToolStripMenuItem,
            this.commentToolStripMenuItem1,
            this.ratingToolStripMenuItem1,
            this.documentDownloadToolStripMenuItem,
            this.userRoleToolStripMenuItem,
            this.toolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // regularUserToolStripMenuItem
            // 
            this.regularUserToolStripMenuItem.Name = "regularUserToolStripMenuItem";
            this.regularUserToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.regularUserToolStripMenuItem.Text = "Register User";
            this.regularUserToolStripMenuItem.Click += new System.EventHandler(this.regularUserToolStripMenuItem_Click);
            // 
            // skillToolStripMenuItem
            // 
            this.skillToolStripMenuItem.Name = "skillToolStripMenuItem";
            this.skillToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.skillToolStripMenuItem.Text = "Skill";
            this.skillToolStripMenuItem.Click += new System.EventHandler(this.skillToolStripMenuItem_Click);
            // 
            // authorToolStripMenuItem1
            // 
            this.authorToolStripMenuItem1.Name = "authorToolStripMenuItem1";
            this.authorToolStripMenuItem1.Size = new System.Drawing.Size(226, 26);
            this.authorToolStripMenuItem1.Text = "Author";
            this.authorToolStripMenuItem1.Click += new System.EventHandler(this.authorToolStripMenuItem1_Click);
            // 
            // conferenceToolStripMenuItem1
            // 
            this.conferenceToolStripMenuItem1.Name = "conferenceToolStripMenuItem1";
            this.conferenceToolStripMenuItem1.Size = new System.Drawing.Size(226, 26);
            this.conferenceToolStripMenuItem1.Text = "Conference";
            // 
            // documentUploadToolStripMenuItem
            // 
            this.documentUploadToolStripMenuItem.Name = "documentUploadToolStripMenuItem";
            this.documentUploadToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.documentUploadToolStripMenuItem.Text = "Document Upload";
            this.documentUploadToolStripMenuItem.Click += new System.EventHandler(this.documentUploadToolStripMenuItem_Click);
            // 
            // reviewerToolStripMenuItem1
            // 
            this.reviewerToolStripMenuItem1.Name = "reviewerToolStripMenuItem1";
            this.reviewerToolStripMenuItem1.Size = new System.Drawing.Size(226, 26);
            this.reviewerToolStripMenuItem1.Text = "Reviewer";
            this.reviewerToolStripMenuItem1.Click += new System.EventHandler(this.reviewerToolStripMenuItem1_Click);
            // 
            // peerReviewerToolStripMenuItem
            // 
            this.peerReviewerToolStripMenuItem.Name = "peerReviewerToolStripMenuItem";
            this.peerReviewerToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.peerReviewerToolStripMenuItem.Text = "Peer Reviewer";
            this.peerReviewerToolStripMenuItem.Click += new System.EventHandler(this.peerReviewerToolStripMenuItem_Click);
            // 
            // commentToolStripMenuItem1
            // 
            this.commentToolStripMenuItem1.Name = "commentToolStripMenuItem1";
            this.commentToolStripMenuItem1.Size = new System.Drawing.Size(226, 26);
            this.commentToolStripMenuItem1.Text = "Comment";
            this.commentToolStripMenuItem1.Click += new System.EventHandler(this.commentToolStripMenuItem1_Click);
            // 
            // ratingToolStripMenuItem1
            // 
            this.ratingToolStripMenuItem1.Name = "ratingToolStripMenuItem1";
            this.ratingToolStripMenuItem1.Size = new System.Drawing.Size(226, 26);
            this.ratingToolStripMenuItem1.Text = "Rating";
            // 
            // documentDownloadToolStripMenuItem
            // 
            this.documentDownloadToolStripMenuItem.Name = "documentDownloadToolStripMenuItem";
            this.documentDownloadToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.documentDownloadToolStripMenuItem.Text = "Document Download";
            // 
            // userRoleToolStripMenuItem
            // 
            this.userRoleToolStripMenuItem.Name = "userRoleToolStripMenuItem";
            this.userRoleToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.userRoleToolStripMenuItem.Text = "User Role";
            this.userRoleToolStripMenuItem.Click += new System.EventHandler(this.userRoleToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(223, 6);
            // 
            // listToolStripMenuItem
            // 
            this.listToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allRoleInformationToolStripMenuItem,
            this.skillInformationToolStripMenuItem,
            this.skillInformationToolStripMenuItem1,
            this.researchWorkToolStripMenuItem,
            this.commentToolStripMenuItem,
            this.reviewerToolStripMenuItem,
            this.ratingToolStripMenuItem,
            this.userInformationToolStripMenuItem,
            this.conferenceToolStripMenuItem,
            this.userRoleToolStripMenuItem1,
            this.reviewerResearchWorkToolStripMenuItem});
            this.listToolStripMenuItem.Name = "listToolStripMenuItem";
            this.listToolStripMenuItem.Size = new System.Drawing.Size(43, 24);
            this.listToolStripMenuItem.Text = "&List";
            // 
            // allRoleInformationToolStripMenuItem
            // 
            this.allRoleInformationToolStripMenuItem.Name = "allRoleInformationToolStripMenuItem";
            this.allRoleInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.allRoleInformationToolStripMenuItem.Text = "All Role Information";
            this.allRoleInformationToolStripMenuItem.Click += new System.EventHandler(this.allRoleInformationToolStripMenuItem_Click_1);
            // 
            // skillInformationToolStripMenuItem
            // 
            this.skillInformationToolStripMenuItem.Name = "skillInformationToolStripMenuItem";
            this.skillInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.skillInformationToolStripMenuItem.Text = "Author Information";
            this.skillInformationToolStripMenuItem.Click += new System.EventHandler(this.skillInformationToolStripMenuItem_Click);
            // 
            // skillInformationToolStripMenuItem1
            // 
            this.skillInformationToolStripMenuItem1.Name = "skillInformationToolStripMenuItem1";
            this.skillInformationToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.skillInformationToolStripMenuItem1.Text = "Skill Information";
            this.skillInformationToolStripMenuItem1.Click += new System.EventHandler(this.skillInformationToolStripMenuItem1_Click);
            // 
            // researchWorkToolStripMenuItem
            // 
            this.researchWorkToolStripMenuItem.Name = "researchWorkToolStripMenuItem";
            this.researchWorkToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.researchWorkToolStripMenuItem.Text = "Research Work";
            this.researchWorkToolStripMenuItem.Click += new System.EventHandler(this.researchWorkToolStripMenuItem_Click);
            // 
            // commentToolStripMenuItem
            // 
            this.commentToolStripMenuItem.Name = "commentToolStripMenuItem";
            this.commentToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.commentToolStripMenuItem.Text = "Comment";
            this.commentToolStripMenuItem.Click += new System.EventHandler(this.commentToolStripMenuItem_Click);
            // 
            // reviewerToolStripMenuItem
            // 
            this.reviewerToolStripMenuItem.Name = "reviewerToolStripMenuItem";
            this.reviewerToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.reviewerToolStripMenuItem.Text = "Reviewer Information";
            this.reviewerToolStripMenuItem.Click += new System.EventHandler(this.reviewerToolStripMenuItem_Click);
            // 
            // ratingToolStripMenuItem
            // 
            this.ratingToolStripMenuItem.Name = "ratingToolStripMenuItem";
            this.ratingToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.ratingToolStripMenuItem.Text = "Rating";
            // 
            // userInformationToolStripMenuItem
            // 
            this.userInformationToolStripMenuItem.Name = "userInformationToolStripMenuItem";
            this.userInformationToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.userInformationToolStripMenuItem.Text = "User Information";
            this.userInformationToolStripMenuItem.Click += new System.EventHandler(this.userInformationToolStripMenuItem_Click);
            // 
            // conferenceToolStripMenuItem
            // 
            this.conferenceToolStripMenuItem.Name = "conferenceToolStripMenuItem";
            this.conferenceToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.conferenceToolStripMenuItem.Text = "Conference";
            this.conferenceToolStripMenuItem.Click += new System.EventHandler(this.conferenceToolStripMenuItem_Click);
            // 
            // userRoleToolStripMenuItem1
            // 
            this.userRoleToolStripMenuItem1.Name = "userRoleToolStripMenuItem1";
            this.userRoleToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.userRoleToolStripMenuItem1.Text = "User Role";
            this.userRoleToolStripMenuItem1.Click += new System.EventHandler(this.userRoleToolStripMenuItem1_Click);
            // 
            // reviewerResearchWorkToolStripMenuItem
            // 
            this.reviewerResearchWorkToolStripMenuItem.Name = "reviewerResearchWorkToolStripMenuItem";
            this.reviewerResearchWorkToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.reviewerResearchWorkToolStripMenuItem.Text = "Reviewer Research Work";
            this.reviewerResearchWorkToolStripMenuItem.Click += new System.EventHandler(this.reviewerResearchWorkToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchByWordToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.searchToolStripMenuItem.Text = "&Search";
            // 
            // searchByWordToolStripMenuItem
            // 
            this.searchByWordToolStripMenuItem.Name = "searchByWordToolStripMenuItem";
            this.searchByWordToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.searchByWordToolStripMenuItem.Text = "&Search by word";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(149, 26);
            this.aboutToolStripMenuItem.Text = "&About";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(543, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 355);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(543, 25);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(50, 20);
            this.toolStripStatusLabel1.Text = "Ready";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 380);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "frmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem appToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allRoleInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem skillInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skillInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem researchWorkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reviewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ratingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conferenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchByWordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regularUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skillToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem conferenceToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem documentUploadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reviewerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem peerReviewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ratingToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem documentDownloadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userRoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userRoleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem reviewerResearchWorkToolStripMenuItem;
    }
}