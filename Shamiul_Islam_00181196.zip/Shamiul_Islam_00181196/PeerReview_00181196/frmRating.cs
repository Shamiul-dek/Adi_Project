﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmRating : Form
    {
        Database1Entities db = new Database1Entities(); 
        public frmRating()
        {
            InitializeComponent();
        }

        private void frmRating_Load(object sender, EventArgs e)
        {
            //--Get combobox data from comment
            var data1 = db.Comments.Select(d=> new { d.Id, Name = d.PeerReview.Reviewer.Name }).ToList();

            cboComment.DataSource = data1;
            cboComment.DisplayMember = "Name";
            cboComment.ValueMember = "Id";

            //--Get combobox data from ResearchWork

            var data2 = db.ResearchWorks.Select(d => new { d.Id, d.Doc }).ToList();

            cboDocument.DataSource = data2;
            cboDocument.DisplayMember = "Doc";
            cboDocument.ValueMember = "Id"; 
        }

     

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            lblRating.Text = hScrollBar1.Value.ToString();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Rating rat = new Rating()
            {
                RatingValue = hScrollBar1.Value,
                commentId = Int32.Parse(cboComment.SelectedValue.ToString()),
                authorDocId = Int32.Parse(cboDocument.SelectedValue.ToString())
            };

            db.Ratings.Add(rat);
            db.SaveChanges();

            txtId.Text = rat.Id.ToString();
            MessageBox.Show("Data save successfully..");
        }
    }
}
