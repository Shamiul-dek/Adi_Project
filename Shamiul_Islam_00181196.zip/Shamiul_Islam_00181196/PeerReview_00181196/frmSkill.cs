﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmSkill : Form
    {
        Database1Entities db = new Database1Entities();
        public frmSkill()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Skill sk = new Skill();
            sk.Name = txtName.Text;
            sk.Desscription = txtDesc.Text;

            db.Skills.Add(sk);
            db.SaveChanges();

            txtId.Text = sk.Id.ToString();
            MessageBox.Show("Data save successfully");
        }
    }
}
