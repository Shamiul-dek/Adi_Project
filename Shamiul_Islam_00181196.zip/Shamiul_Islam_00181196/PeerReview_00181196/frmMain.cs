﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void allRoleInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserRolelist frm = new frmUserRolelist();
            frm.Show();


        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void allRoleInformationToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmUserRolelist frm = new frmUserRolelist();
            frm.Show();

        }

        private void userRoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserRole frm = new frmUserRole();
            frm.Show();
        }

        private void userRoleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmUserRolelist frm = new PeerReview_00181196.frmUserRolelist();
            frm.Show();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = string.Format("Welcome {0} [{1}]", clsUserData.UserName, clsUserData.RoleName);

            if (clsUserData.RoleName.ToLower() != "Admin".ToLower())
            {
                skillToolStripMenuItem.Visible = false;
                userInformationToolStripMenuItem.Visible = false;
                
            }

            if (clsUserData.RoleName.ToLower() != "Author".ToLower())
            {
                authorToolStripMenuItem1.Visible = false;
                documentUploadToolStripMenuItem.Visible = false;

            }

            if (clsUserData.RoleName.ToLower() != "Reviewer".ToLower())
            {
                reviewerToolStripMenuItem.Visible = false;
            }
            
        }
        

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogIn frm = new frmLogIn();
            frm.Show();
        }

        private void regularUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccount frm = new frmAccount();
            frm.Show();
        }

        private void skillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSkill frm = new frmSkill();
            frm.Show();
        }

        private void skillInformationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            List.frmListSkill frm = new List.frmListSkill();
            frm.Show();
        }

        private void authorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmAuthor frm = new frmAuthor();
            frm.Show();
        }

        private void userInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListUserInfo frm = new List.frmListUserInfo();
            frm.Show();
        }

        private void skillInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListAuthor frm = new List.frmListAuthor();
            frm.Show();
        }

        private void reviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListReviewer frm = new List.frmListReviewer();
            frm.Show();
        }

        private void researchWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListResearchWork frm = new List.frmListResearchWork();
            frm.Show();
        }

        private void conferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListConference frm = new List.frmListConference();
            frm.Show();
        }

        private void commentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListComment frm = new List.frmListComment();
            frm.Show();
        }

        private void reviewerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmReviewer frm = new frmReviewer();
            frm.Show();
        }

        private void documentUploadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmResearchWork frm = new frmResearchWork();
            frm.Show();
        }

        private void peerReviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPeerReview frm = new frmPeerReview();
            frm.Show();
        }

        private void reviewerResearchWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List.frmListAssighnedResearchWork frm = new List.frmListAssighnedResearchWork();
            frm.Show();
        }

        private void commentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmComment frm = new frmComment();
            frm.Show();
        }
    }
}
