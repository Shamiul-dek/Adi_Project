﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmConference : Form
    {
        Database1Entities db = new Database1Entities();
        public frmConference()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

            ProjectConference pConf = new ProjectConference()
            {
                cTitle = txtTitle.Text,
                pDescription = txtDescription.Text,
                StartDate = dateTimePicker1.Value

            };

            db.ProjectConferences.Add(pConf);
            db.SaveChanges();

            txtId.Text = pConf.Id.ToString();
            MessageBox.Show("Data Save Succesfully");

        

    }

        private void frmConference_Load(object sender, EventArgs e)
        {

        }
    }
}
