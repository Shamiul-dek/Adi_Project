﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmDownload : Form
    {
        Database1Entities db = new Database1Entities();
        public frmDownload()
        {
            InitializeComponent();
        }

        private void frmDownload_Load(object sender, EventArgs e)
        {
            //Get Reviewer Id
            int uid = clsUserData.UserId;
            var revw = db.Reviewers.Where(d => d.uId == uid).FirstOrDefault();
            int reviewerId = revw.Id;
            //--------------------------------

            var data = db.PeerReviews.Select(d => new { d.reviewerId, d.docId, doc = d.ResearchWork.Doc })
                .Where(d => d.reviewerId == reviewerId).ToList();

            CboDocType.Items.Add("---Select----");
            foreach (var item in data)
            {
                CboDocType.Items.Add(item);
            }

            CboDocType.DisplayMember = "doc";
            CboDocType.ValueMember = "docId";
            CboDocType.SelectedIndex = 0;

            btnDownload.Enabled = false;
            btnView.Enabled = false;

        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (txtDoc.Text == "")
            {
                MessageBox.Show(" Please Search a document !!!");
                return;
            }

            try
            {
                string pathDestination = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), CboDocType.Text);
                string pathSource = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
                File.Copy(pathSource + "\\Upload\\" + txtDoc.Text, pathDestination, true);
                MessageBox.Show("Please check in desktop...");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            string pathDestination = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), CboDocType.Text);
            string pathSource = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
            System.Diagnostics.Process.Start(pathSource + "\\Upload\\" + txtDoc.Text);
        }

        private void CboDocType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CboDocType.Text != "---Select---")
            {
                txtDoc.Text = CboDocType.Text;
                btnDownload.Enabled = true;
                btnView.Enabled = true;
            }

            else
            {
                txtDoc.Text = CboDocType.Text;
                btnDownload.Enabled = false;
                btnView.Enabled = false;
            }
        }
    }
}
