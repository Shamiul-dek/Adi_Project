﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeerReview_00181196
{
    public partial class frmUserRole : Form
    {
        Database1Entities db = new Database1Entities();
        public frmUserRole()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                UserRole role = new UserRole();
                role.Name = txtName.Text;
                db.UserRoles.Add(role);

                db.SaveChanges();

                txtId.Text = role.Id.ToString();
                MessageBox.Show("Data Inserted successfully..!", "Insert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                MessageBox.Show("Data Already exists !!!", "Insert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

           
           
            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
